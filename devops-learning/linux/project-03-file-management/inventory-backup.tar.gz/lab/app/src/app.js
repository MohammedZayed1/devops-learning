consol.log('Inventory App');
